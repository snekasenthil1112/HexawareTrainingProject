package model;

public class Loan {
    private int loanId;
    private int customerId; //fpreign
    private double loanAmount;
    private double interestRate;
    private int loanTerm;
    private String loanType;
    private String loanStatus;

    
    public Loan() {}

    public Loan(int loanId, int customerId, double loanAmount, double interestRate, int loanTerm, String loanType, String Status) {
        this.loanId = loanId;
        this.customerId = customerId;
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.loanTerm = loanTerm;
        this.loanType = loanType;
        this.loanStatus = loanStatus;
    }

    public int getLoanId() { return loanId; }
    public void setLoanId(int loanId) { this.loanId = loanId; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public double getloanAmount() { return loanAmount; }
    public void setloanAmount(double principalAmount) { this.loanAmount = loanAmount; }

    public double getInterestRate() { return interestRate; }
    public void setInterestRate(double interestRate) { this.interestRate = interestRate; }

    public int getLoanTerm() { return loanTerm; }
    public void setLoanTerm(int loanTerm) { this.loanTerm = loanTerm; }

    public String getLoanType() { return loanType; }
    public void setLoanType(String loanType) { this.loanType = loanType; }

    public String getStatus() { return loanStatus; }
    public void setLoanStatus(String loanStatus) { this.loanStatus = loanStatus; }

    public void printDetails() {
        System.out.println("Loan ID: " + loanId);
        System.out.println("Customer ID: " + customerId);
        System.out.println("Principal Amount: " + loanAmount);
        System.out.println("Interest Rate: " + interestRate);
        System.out.println("Loan Term: " + loanTerm);
        System.out.println("Loan Type: " + loanType);
        System.out.println("Loan Status: " + loanStatus);
    }

	public double getAmount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getloanTerm() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getLoanAmount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLoanterm() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getCreditScore() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
}