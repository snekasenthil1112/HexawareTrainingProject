package repository;
import java.sql.*;
import java.util.*;

import exception.InvalidLoanException;
import model.Loan;

public class LoanRepositoryImpl implements ILoanRepository {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/Loan";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    @Override
    public void applyLoan(Loan loan) {
        // Prompt for user confirmation
        System.out.print("Do you want to apply for this loan? (Yes/No): ");
        Scanner scanner = new Scanner(System.in);
        String confirmation = scanner.nextLine();

        // Check if customerId exists in the Customer table
        if (confirmation.equalsIgnoreCase("Yes")) {
            String checkCustomerQuery = "SELECT COUNT(*) FROM Customer WHERE customerId = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement checkStmt = conn.prepareStatement(checkCustomerQuery)) {
                checkStmt.setInt(1, loan.getCustomerId());
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    // If customerId exists, proceed with loan application
                    String sql = "INSERT INTO Loan (customerId, loanAmount, interestRate, loanTerm, loanType, loanStatus) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, loan.getCustomerId());
                        stmt.setDouble(2, loan.getLoanAmount());
                        stmt.setDouble(3, loan.getInterestRate());
                        stmt.setInt(4, loan.getLoanTerm());
                        stmt.setString(5, loan.getLoanType());
                        stmt.setString(6, "Pending");
                        stmt.executeUpdate();
                        System.out.println("Loan application submitted successfully.");
                    }
                } else {
                    System.out.println("Customer ID does not exist. Loan application cannot proceed.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Loan application canceled.");
        }
    }



    @Override
    public double calculateInterest(int loanId) throws InvalidLoanException {
        String query = "SELECT loanAmount, interestRate, loanTerm FROM Loan WHERE loanId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                double principal = rs.getDouble("loanAmount");
                double interestRate = rs.getDouble("interestRate");
                int loanTerm = rs.getInt("loanTerm");
                return (principal * interestRate * loanTerm) / 12;
            } else {
                throw new InvalidLoanException("Loan not found for ID: " + loanId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double calculateInterest(double loanAmount, double interestRate, int loanTerm) {
        return (loanAmount * interestRate * loanTerm) / 12;
    }

    @Override
    public void loanStatus(int loanId) throws InvalidLoanException {
        String query = "SELECT c.creditScore FROM Loan l JOIN Customer c ON l.customerId = c.customerId WHERE l.loanId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int creditScore = rs.getInt("creditScore");
                String loanStatus = creditScore > 650 ? "Approved" : "Rejected";
                
                // Update loanStatus in database (not 'status')
                String updateQuery = "UPDATE Loan SET loanStatus = ? WHERE loanId = ?";  // Corrected here
                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                    updateStmt.setString(1, loanStatus);
                    updateStmt.setInt(2, loanId);
                    updateStmt.executeUpdate();
                    System.out.println("Loan " + loanStatus);
                }
            } else {
                throw new InvalidLoanException("Loan not found for ID: " + loanId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @Override
    public double calculateEMI(int loanId) throws InvalidLoanException {
        String query = "SELECT loanAmount, interestRate, loanTerm FROM Loan WHERE loanId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                double loanAmount = rs.getDouble("loanAmount");
                double interestRate = rs.getDouble("interestRate") / 12 / 100;
                int loanTerm = rs.getInt("loanTerm");
                double emi = (loanAmount * interestRate * Math.pow(1 + interestRate, loanTerm)) /
                             (Math.pow(1 + interestRate, loanTerm) - 1);
                return emi;
            } else {
                throw new InvalidLoanException("Loan not found for ID: " + loanId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double calculateEMI(double loanAmount, double interestRate, int loanTerm) {
        interestRate = interestRate / 12 / 100; // Monthly rate
        double emi = (loanAmount * interestRate * Math.pow(1 + interestRate, loanTerm)) /
                     (Math.pow(1 + interestRate, loanTerm) - 1);
        return emi;
    }

    @Override
    public void loanRepayment(int loanId, double amount) throws InvalidLoanException {
        String query = "SELECT loanAmount, noOfEmiPaid, loanTerm, interestRate FROM Loan WHERE loanId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                double loanAmount = rs.getDouble("loanAmount");
                int noOfEmiPaid = rs.getInt("noOfEmiPaid");
                int loanTerm = rs.getInt("loanTerm");
                double interestRate = rs.getDouble("interestRate");  // Now fetching interestRate

                double emi = calculateEMI(loanAmount, interestRate, loanTerm);  // Pass interestRate here
                if (amount < emi) {
                    System.out.println("Amount is less than one EMI. Payment rejected.");
                    return;
                }

                int emiPaid = (int) (amount / emi);
                noOfEmiPaid += emiPaid;

                if (noOfEmiPaid > loanTerm) {
                    noOfEmiPaid = loanTerm; // Can't exceed loan tenure
                }

                String updateQuery = "UPDATE Loan SET noOfEmiPaid = ? WHERE loanId = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                    updateStmt.setInt(1, noOfEmiPaid);
                    updateStmt.setInt(2, loanId);
                    updateStmt.executeUpdate();
                    System.out.println("EMIs paid: " + emiPaid);
                }
            } else {
                throw new InvalidLoanException("Loan not found for ID: " + loanId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public List<Loan> getAllLoan() {
        List<Loan> loans = new ArrayList<>();
        String query = "SELECT * FROM Loan";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Loan loan = new Loan();
                loan.setLoanId(rs.getInt("loanId"));
                loan.setCustomerId(rs.getInt("customerId"));
                loan.setLoanAmount(rs.getDouble("loanAmount"));
                loan.setInterestRate(rs.getDouble("interestRate"));
                loan.setLoanTerm(rs.getInt("loanTerm"));
                loan.setLoanType(rs.getString("loanType"));
                loan.setLoanStatus(rs.getString("loanStatus"));
                loans.add(loan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return loans;
    }


    @Override
    public Loan getLoanById(int loanId) throws InvalidLoanException {
        String query = "SELECT * FROM Loan WHERE loanId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Loan loan = new Loan();
                loan.setLoanId(rs.getInt("loanId"));
                loan.setCustomerId(rs.getInt("customerId"));
                loan.setLoanAmount(rs.getDouble("loanAmount"));
                loan.setInterestRate(rs.getDouble("interestRate"));
                loan.setLoanTerm(rs.getInt("loanTerm"));
                loan.setLoanType(rs.getString("loanType"));
                loan.setLoanStatus(rs.getString("loanStatus"));
                return loan;
            } else {
                throw new InvalidLoanException("Loan not found for ID: " + loanId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}