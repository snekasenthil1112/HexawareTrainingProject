package service;

import util.Connection;

public class DriverManager {

	public static Connection getConnection(String url, String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
