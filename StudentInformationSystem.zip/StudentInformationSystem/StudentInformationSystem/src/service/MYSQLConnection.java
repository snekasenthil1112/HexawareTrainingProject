package service;

import java.sql.*;

public class MYSQLConnection {

    public static void main(String[] args) {
        // JDBC URL, username and password of MySQL server
        String url = "jdbc:mysql://localhost:3306/SISDB"; // Make sure SISDB exists
        String user = "root"; // your MySQL username
        String password = "root"; // your MySQL password

        // Load MySQL JDBC Driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver Registered!");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
            return;
        }

        // Establishing the connection
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            System.out.println("✅ Connected to MySQL!");

            // Test query
            String query = "SELECT * FROM students";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
            	System.out.println("ID: " + rs.getInt("student_id") + 
                        ", Name: " + rs.getString("studentName") + 
                        ", Email: " + rs.getString("email"));
 }

        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
        }
    }
}
