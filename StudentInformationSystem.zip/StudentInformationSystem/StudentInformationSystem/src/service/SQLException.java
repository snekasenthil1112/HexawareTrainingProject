package service;

public class SQLException extends Exception {

}
