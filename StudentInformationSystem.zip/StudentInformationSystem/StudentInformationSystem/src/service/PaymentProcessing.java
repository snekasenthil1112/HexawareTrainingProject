package service;

import model.Payment;
import java.util.ArrayList;
import java.util.List;

public class PaymentProcessor {
    private List<Payment> payments = new ArrayList<>();

    public void recordPayment(Payment payment) {
        payments.add(payment);
        System.out.println("Payment recorded: " + payment.getAmount() + " by student ID " + payment.getStudentId());
    }

    public List<Payment> getAllPayments() {
        return payments;
    }
}
