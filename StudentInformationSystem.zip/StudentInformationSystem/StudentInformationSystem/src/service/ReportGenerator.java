package service;
import java.util.stream.Collectors;

import model.Course;
import model.Enrollment;
import model.Payment;

import java.util.*;
import java.util.stream.Collectors;

public class ReportGenerator {

    // Method to generate a course-wise report
    public void generateCourseWiseReport(List<Enrollment> enrollments, List<Payment> payments) {
        // Map with courseId as the key and a list of enrollments as the value
        Map<Integer, List<Enrollment>> courseEnrollments = new HashMap<>();

        // Group enrollments by courseId
        for (Enrollment e : enrollments) {
            courseEnrollments.computeIfAbsent(e.getCourseId(), k -> new ArrayList<>()).add(e);
        }

        // Iterate over the map and generate the report
        for (Map.Entry<Integer, List<Enrollment>> entry : courseEnrollments.entrySet()) {
            int courseId = entry.getKey();
            List<Enrollment> studentList = entry.getValue();

            if (!studentList.isEmpty()) {
                // Assuming the first enrollment in the list provides enough details to get the course
                Course course = studentList.get(0).getCourse();
                System.out.println("\nCourse: " + course.getCourseName() + " (" + course.getCourseCode() + ")");

                // Print student details for each enrollment
                for (Enrollment e : studentList) {
                    System.out.println(" - Student ID: " + e.getStudentId());
                }
            }

            Map<Integer, Double> studentPaymentMap = new HashMap<>();
            for (Payment p : payments) {
                studentPaymentMap.put(
                    p.getStudentId(),
                    studentPaymentMap.getOrDefault(p.getStudentId(), 0.0) + p.getAmount()
                );
            }

            System.out.println("\n📊 Total Payments Made by Each Student:");
            for (Map.Entry<Integer, Double> entry1 : studentPaymentMap.entrySet()) {
                System.out.println(" - Student ID: " + entry1.getKey() + ", Total Paid: ₹" + entry1.getValue());
            }
        }
    }

    // Method to generate report for students who have not made any payments
    public void generateStudentsWithNoPayments(List<Enrollment> enrollments, List<Payment> payments) {
        // Get all student IDs who are enrolled
        Set<Integer> enrolledStudentIds = enrollments.stream()
                .map(Enrollment::getStudentId)
                .collect(Collectors.toSet());

        // Get all student IDs who have made payments
        Set<Integer> paidStudentIds = payments.stream()
                .map(Payment::getStudentId)
                .collect(Collectors.toSet());

        // Find the difference to get students who have not made any payments
        enrolledStudentIds.removeAll(paidStudentIds);

        // Display students who have not made any payments
        if (!enrolledStudentIds.isEmpty()) {
            System.out.println("\n🚫 Students who have not made any payments yet:");
            for (Integer studentId : enrolledStudentIds) {
                System.out.println(" - Student ID: " + studentId);
            }
        } else {
            System.out.println("\n✅ All students have made payments.");
        }
    }
}
