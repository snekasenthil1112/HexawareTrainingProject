package service;

import model.Payment;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PaymentProcessor {
    private List<Payment> payments = new ArrayList<>(); // ✅ initialize the list

    public void recordPayment(Payment payment) {
        payments.add(payment);
        System.out.println("✅ Payment recorded: " + payment.getAmount() + " by " + payment.getPaymentMode());
    }

    public List<Payment> getPaymentsByStudentId(int studentId) {
        List<Payment> result = new ArrayList<>();
        for (Payment p : payments) {
            if (p.getStudentId() == studentId) {
                result.add(p);
            }
        }
        return result;
    }
    public List<Payment> getPaymentsWithinDateRange(LocalDate startDate, LocalDate endDate) {
        List<Payment> result = new ArrayList<>();
        for (Payment payment : payments) {
            if ((payment.getPaymentDate().isEqual(startDate) || payment.getPaymentDate().isAfter(startDate)) &&
                (payment.getPaymentDate().isEqual(endDate) || payment.getPaymentDate().isBefore(endDate))) {
                result.add(payment);
            }
        }
        return result;
    }

}
