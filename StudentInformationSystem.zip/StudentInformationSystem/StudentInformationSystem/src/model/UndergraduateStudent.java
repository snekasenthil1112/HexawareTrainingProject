package model;

public class UndergraduateStudent {

}
