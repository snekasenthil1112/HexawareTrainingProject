package model;

public class Course {
    private int courseId;
    private String courseName;
    private String courseCode;
    private String instructor;

    // Constructor
    public Course(int courseId, String courseName, String courseCode, String instructor) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.instructor = instructor;
    }

    // Getters
    public String getCourseName() {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getInstructor() {
        return instructor;
    }
}
