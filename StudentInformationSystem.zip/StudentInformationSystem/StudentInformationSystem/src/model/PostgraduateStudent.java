package model;

public class PostgraduateStudent {

}
