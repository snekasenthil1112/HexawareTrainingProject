package model;

import java.time.LocalDate;

import exception.InvalidEmailFormatException;
import exception.InvalidStudentIdException;

public class Enrollment {
    private int enrollmentId;
    private int studentId;
    private int courseId;
    private String courseName;
    private LocalDate enrollmentDate;

    public Enrollment(int studentId, int courseId, String courseName, LocalDate enrollmentDate) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.courseName = courseName;
        this.enrollmentDate = enrollmentDate;
    }

    // Getters
    public int getCourseId() {
        return this.courseId;
    }

    public int getStudentId() {
        return this.studentId;
    }

    public Course getCourse() {
        return new Course(courseId, courseName, "CS101", "Mr. Ram"); // Assuming Course is available
    }

    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }
	public String getCourseName() {
		// TODO Auto-generated method stub
		return this.courseName;
	}
}


