package model;

import java.time.LocalDate;

public class Payment {
    private int paymentId;
    private int studentId;
    private double amount;
    private LocalDate paymentDate;
    private String paymentMethod;
    private String paymentMode;
    // Constructor
    public Payment(int paymentId, int studentId, double amount, LocalDate paymentDate, String paymentMethod, String paymentMode) {
        this.paymentId = paymentId;
        this.studentId = studentId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.paymentMode = paymentMode; 
    }

    // Getters
    public int getPaymentId() {
        return paymentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

	public String getPaymentMode() {
	    return paymentMode;
}
}
