package model;
import java.util.ArrayList;
import java.util.List;

public class Teacher {
    private int teacherId;
    private String firstName;
    private String lastName;
    private String email;
    private String expertise;
    private List<Course> assignedCourses;

    // Constructor
    public Teacher(int teacherId, String firstName, String lastName, String email, String expertise) {
        this.teacherId = teacherId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.expertise = expertise;
        this.assignedCourses = new ArrayList<>();
    }

    // Method to update teacher info
    public void updateTeacherInfo(String name, String email, String expertise) {
        this.firstName = name;
        this.email = email;
        this.expertise = expertise;
    }

    // Method to display teacher info
    public void displayTeacherInfo() {
        System.out.println("Teacher ID: " + teacherId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Email: " + email);
        System.out.println("Expertise: " + expertise);
    }

    // Method to get assigned courses
    public List<Course> getAssignedCourses() {
        return assignedCourses;
    }

    // Method to add assigned course
    public void addAssignedCourse(Course course) {
        assignedCourses.add(course);
    }
}
