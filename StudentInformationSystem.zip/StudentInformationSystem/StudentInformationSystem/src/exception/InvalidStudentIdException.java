package exception;

public class InvalidStudentIdException {

}
