package exception;

public class InvalidPaymentAmountException {

}
