package exception;

public class InvalidEmailFormatException {

}
