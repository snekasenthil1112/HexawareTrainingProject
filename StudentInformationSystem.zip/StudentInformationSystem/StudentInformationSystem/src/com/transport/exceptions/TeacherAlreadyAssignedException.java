package exception;

package com.transport.exceptions;

public class TeacherAlreadyAssignedException extends Exception {
    public TeacherAlreadyAssignedException(String message) {
        super(message);
    }
}

