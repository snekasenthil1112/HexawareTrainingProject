package com.transport.app;


import model.Course;
import model.Enrollment;
import model.Payment;
import model.Student;
import model.UndergraduateStudent;
import model.PostgraduateStudent;
import service.PaymentProcessor;
import service.ReportGenerator;
import service.StudentSearchService;
import exception.InvalidEmailFormatException;
import exception.InvalidStudentIdException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Student creation
            Student student = new Student(101, "Sneka", "Senthil", "2002-03-12", "sneka@gmail.com", "9876543210");
            Course course1 = new Course(1, "Java Programming", "CS101", "Mr. Ram");
            Course course2 = new Course(2, "Data Structures", "CS102", "Ms. Priya");

            // Enrollment records
            List<Enrollment> enrollments = new ArrayList<>();
            enrollments.add(new Enrollment(student.getStudentId(), course1.getCourseId(), course1.getCourseName(), LocalDate.now()));
            enrollments.add(new Enrollment(102, course1.getCourseId(), course1.getCourseName(), LocalDate.now()));
            enrollments.add(new Enrollment(103, course2.getCourseId(), course2.getCourseName(), LocalDate.now()));

            // Task 6: Report Generation
            ReportGenerator reportGenerator = new ReportGenerator();
            reportGenerator.generateCourseWiseReport(enrollments);

            // Task 5: Inheritance and Polymorphism
            UndergraduateStudent ugStudent = new UndergraduateStudent(102, "Diksha", "Senthil", "2004-07-25", "diksha@gmail.com", "9123456780", "Computer Science");
            PostgraduateStudent pgStudent = new PostgraduateStudent(103, "Kaviya", "Ravi", "2000-05-15", "kaviya@gmail.com", "9988776655", "Artificial Intelligence");

            Student[] students = { student, ugStudent, pgStudent };
            for (Student s : students) {
                System.out.println(s.toString());
            }

            // Task 7: Payment Recording
            PaymentProcessor paymentProcessor = new PaymentProcessor();
            Payment payment = new Payment(1, student.getStudentId(), 5000.00, LocalDate.now(), "Credit Card");
            paymentProcessor.recordPayment(payment);

            // Task 8: Search students by course
            StudentSearchService searchService = new StudentSearchService();
            searchService.searchStudentsByCourse("Java Programming", enrollments);

            // Task 9: Payment History by Student ID
            List<Payment> studentPayments = paymentProcessor.getPaymentsByStudentId(101);
            System.out.println("\n🔍 Payment history for Student ID 101:");
            for (Payment p : studentPayments) {
                System.out.println(" - Amount: " + p.getAmount() + ", Mode: " + p.getPaymentMode());
            }

            // Task 10: Payments within date range
            System.out.println("\n🔍 Payments made between 2024-01-01 and 2025-12-31:");
            List<Payment> filteredPayments = paymentProcessor.getPaymentsWithinDateRange(LocalDate.of(2024, 1, 1), LocalDate.of(2025, 12, 31));
            for (Payment p : filteredPayments) {
                System.out.println(" - Student ID: " + p.getStudentId() + ", Amount: " + p.getAmount() + ", Date: " + p.getPaymentDate() + ", Mode: " + p.getPaymentMode());
            }
            System.out.println("\n🔍 Payments made using mode: Credit Card");
            List<Payment> creditCardPayments = paymentProcessor.getPaymentsByMode("Credit Card");

            for (Payment p : creditCardPayments) {
                System.out.println(" - Student ID: " + p.getStudentId() +
                        ", Amount: " + p.getAmount() +
                        ", Date: " + p.getPaymentDate() +
                        ", Mode: " + p.getPaymentMode());
            }
         // Sample list of payments
            List<Payment> allPayments = new ArrayList<>();
            allPayments.add(new Payment(1, 101, 5000.00, LocalDate.of(2025, 4, 16), "Credit Card"));
            allPayments.add(new Payment(2, 101, 3000.00, LocalDate.of(2025, 5, 5), "Debit Card"));
            allPayments.add(new Payment(3, 102, 4500.00, LocalDate.of(2025, 6, 10), "UPI"));

            // Generate summary report
            reportGenerator.generateTotalPaymentsByStudent(allPayments);


        } catch (InvalidStudentIdException | InvalidEmailFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
}
/*import model.Course;
import model.Enrollment;
import model.Payment;
import service.PaymentProcessor;
import service.ReportGenerator;
import service.StudentSearchService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Sample data to simulate enrollments
        List<Enrollment> enrollments = new ArrayList<>();
        enrollments.add(new Enrollment(101, 1, "Java Programming", LocalDate.now()));
        enrollments.add(new Enrollment(102, 1, "Java Programming", LocalDate.now()));
        enrollments.add(new Enrollment(103, 2, "Data Structures", LocalDate.now()));

        // Create the ReportGenerator instance
        ReportGenerator reportGenerator = new ReportGenerator();

        // Generate and print the course-wise report
        reportGenerator.generateCourseWiseReport(enrollments);
        
         PaymentProcessor paymentProcessor = new PaymentProcessor();

        // Create a sample payment for Student ID 101
        Payment payment = new Payment(1, 101, 5000.00, LocalDate.now(), "Credit Card");

        // Record the payment and generate receipt
        paymentProcessor.recordPayment(payment);
        

        // After payment logic
        StudentSearchService searchService = new StudentSearchService();
        searchService.searchStudentsByCourse("Java Programming", enrollments);
        enrollments.add(new Enrollment(101, 1, "Java Programming", LocalDate.now()));

     // Add this inside PaymentProcessor.java
     // Add this inside PaymentProcessor.java
        List<Payment> getPaymentsByStudentId(int studentId) {
            List<Payment> result = new ArrayList<>();
            Payment[] payments;
			for (Payment p : payments) {
                if (p.getStudentId() == studentId) {
                    result.add(p);
                }
            }
            return;
        }




    }
}

/*import model.Payment;
import service.PaymentProcessor;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Create a PaymentProcessor object
        PaymentProcessor paymentProcessor = new PaymentProcessor();

        // Create a sample payment for Student ID 101
        Payment payment = new Payment(1, 101, 5000.00, LocalDate.now(), "Credit Card");

        // Record the payment and generate receipt
        paymentProcessor.recordPayment(payment);
    }
}*/

